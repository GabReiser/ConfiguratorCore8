/* 
	Script de demonstração de interação, não deve ir para produção.
	by @AlexandreMateus
*/

$(document).ready(function() {	
	
	goToSessionLoginCracha() 	// Inicia o sistema na tela de login com crachá
	//startScreenLoading(2)		// Simula a mensagem de 'carregando do sistema'
    Waves.attach('button');		// Prepara para colocar efeito de click em todos os botões		| http://fian.my.id/Waves/
    Waves.init();				// Inicia o plugin que aplica efeito de click nos botões		| http://fian.my.id/Waves/

});