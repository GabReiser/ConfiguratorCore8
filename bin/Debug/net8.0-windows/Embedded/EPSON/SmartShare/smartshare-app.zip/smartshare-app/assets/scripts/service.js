ip = 'localhost';
BASE_URL = "http://"+ ip + ":8091/service/smartshare";

function sendHttpRequest(resource, method, body, successCallback, failCallback, tryAgainMethod) {
  var xmlHttpRequest = getXmlHttpRequest(resource, method);
  sendRequest(xmlHttpRequest, body, successCallback, failCallback, tryAgainMethod);
}

function sendHttpRequestWithDocType(resource, method, body, successCallback, failCallback, tryAgainMethod) {
  var xmlHttpRequest = getXmlHttpRequest(resource, method, body);

  var docTypeNameSelected = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
  var docTypeId = docTypeNameSelected.docTypeIdSelected;
  xmlHttpRequest.setRequestHeader("DocTypeId", docTypeId);

  sendRequest(xmlHttpRequest, body, successCallback, failCallback, tryAgainMethod);

}

function sendHttpRequestToPreview(resource, method, body, successCallback, failCallback, tryAgainMethod, pagePreview) {
  var xmlHttpRequest = getXmlHttpRequest(resource, method, body);

  var docTypeNameSelected = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
  var docTypeId = docTypeNameSelected.docTypeIdSelected;
  xmlHttpRequest.setRequestHeader("DocTypeId", docTypeId)
  xmlHttpRequest.setRequestHeader("PageNumber", pagePreview)
  sendRequest(xmlHttpRequest, body, successCallback, failCallback, tryAgainMethod);

}


function sendRequest(xmlHttpRequest, body, successCallback, failCallback, tryAgainMethod){
  var page = getCurrentScreen();
  if (page === 'scanning.html' || page === 'scan-properties.html') {
    hideSpinner();
  } else {
    showSpinner();
  }

  xmlHttpRequest.onreadystatechange = function(event) {
    if (xmlHttpRequest.readyState == XMLHttpRequest.DONE) {
        hideSpinner();
        
        if (xmlHttpRequest.status == 200) { 
          successCallback(xmlHttpRequest.response); 
        }  
        if (xmlHttpRequest.status != 200) { 
          failCallback(xmlHttpRequest.status, xmlHttpRequest.response); 
        }
    }
  };

  try {
    xmlHttpRequest.send(body);
  } catch (error) {
    hideSpinner();

    try { closeModal(); } catch (error) {}
    showConnectionLostError(tryAgainMethod);
  }
}

function isLocalEnvironment() {
  var hostname = window.location.hostname;
  return hostname === 'localhost' || hostname.indexOf('127.') === 0 || hostname.indexOf('192.168.') === 0;
}

function getScreenNameIndex() {
  return isLocalEnvironment() ? 3 : 4;
}



function reloadDocType(resource, method, body, successCallback, failCallback, tryAgainMethod){
  var xmlHttpRequest = getXmlHttpRequest(resource, method);
  sendRequestWithOutSpinner(xmlHttpRequest, body, successCallback, failCallback, tryAgainMethod);
}

function getXmlHttpRequest(resource, method){
  var xmlHttpRequest = new XMLHttpRequest();
  var url = this.BASE_URL + resource;

  xmlHttpRequest.open(method, url, false);
  xmlHttpRequest.setRequestHeader("Custom-DeviceIP","172.16.0.250");  
  xmlHttpRequest.setRequestHeader("Content-Type","application/json");

  return xmlHttpRequest;
}

function listProcess() {
  var successCallback = function(response) {
      var processResponse = JSON.parse(response);
      if (processResponse.processList != null){
          processList = processResponse.processList;
          listitems = processList;
          updateListPage(appendProcessItems);
      }
  };

  var failCallback = function(status) {
      if (status == 404)
          showConnectionLostError("tryAgain(listProcess)");
      else
          showErrorModal();
  };

  sendHttpRequest("/process", "GET", null, successCallback, failCallback, "tryAgain(listProcess)");
}

function sendLogin() {
  var successCallback = function(response) {
      var processInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
      var stringProcessId = "{\"processId\": \"" + processInfo.process.processId + "\"}"
      listIndexes(stringProcessId);
  };

  var failCallback = function(status) {
      if (status == 404)
          showConnectionLostError("");
      if (status == 401)
          showInvalidLoginError();
      else
          showErrorModal();
  };

  sendHttpRequest("/process/userAuth", "POST", btoa(getInputs()), successCallback, failCallback, "");
}


function listIndexes(processId) {
  var successCallback = function(response) {
      var processInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
      processInfo.indexes = JSON.parse(response);
      window.sessionStorage.setItem("mainProcessInfo", JSON.stringify(processInfo));

      navigateTo("indexes.html");
  };

  var failCallback = function(status) {
      if (status == 404)
          showConnectionLostError("tryAgain(listProcess)");
      else
          showErrorModal();
  };

  sendHttpRequest("/process/indexes", "POST", processId, successCallback, failCallback, "tryAgain(listProcess)");
}

function listIndexesResult(listIndexes) {
  var successCallback = function(response) {
      var processInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
      processInfo.indexResult = JSON.parse(response);
      window.sessionStorage.setItem("mainProcessInfo", JSON.stringify(processInfo));

      navigateTo("index-result.html");
  };

  var failCallback = function(status, response) {

    switch (status){
    case 451:
      showAlertModal("Falha na consulta", response)
      break;
    case 404:
      showConnectionLostError("tryAgain(listProcess)");
      break;
    default:
      showErrorModal();
      break;
    }
  };

  sendHttpRequest("/process/indexes/result", "POST", JSON.stringify(listIndexes), successCallback, failCallback, "tryAgain(listProcess)");
}

function listDocumentsType(listIndexesResult) {
  var successCallback = function(response) {
    var processInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo")); /*INSTANCIA*/
    processInfo.docTypes = JSON.parse(response); /*PREENCHENDO O DOCTYPE*/
    window.sessionStorage.setItem("mainProcessInfo", JSON.stringify(processInfo)); /*SALVANDO O PREENCHIMENTO*/

      navigateTo("doc-type.html");
  };

  var failCallback = function(status) {
      if (status == 404)
          showConnectionLostError("tryAgain(listDocumentsType)");
      else
          showErrorModal();
  };

  sendHttpRequest("/process/document", "POST", JSON.stringify(listIndexesResult), successCallback, failCallback, "tryAgain(listDocumentsType)");
}

function listDocumentsTypeRe() {
  var successCallback = function(response) {
    var processInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo")); /*INSTANCIA*/
    processInfo.docTypes = JSON.parse(response); /*PREENCHENDO O DOCTYPE*/
    window.sessionStorage.setItem("mainProcessInfo", JSON.stringify(processInfo)); /*SALVANDO O PREENCHIMENTO*/

  };

  var failCallback = function(status) {
      if (status == 404)
          showConnectionLostError("tryAgain(listDocumentsType)");
      else
          showErrorModal();
  };

  sendHttpRequest("/process/document", "POST", "", successCallback, failCallback, "tryAgain(listDocumentsType)");
}
function startScan() {
  var successCallback = function (response) { 

    navigateTo('scanning.html'); 

  };
  var failCallback = function(status) { showErrorModal(); };
  sendHttpRequestWithDocType('/scan/startScan', 'POST', JSON.stringify(settings), successCallback, failCallback, true);  
}

function cancelScanning(){  
  var digText = document.getElementById('digText');
  digText.innerHTML = translate.cancelingScan;

  var btnCancel = document.getElementById('btn-cancel-scan');
  btnCancel.classList.add('disable')
    //chamada servidor excluir scan
    var successCallback = function (response) { 
      btnCancel.classList.add('disable')
    };
    var failCallback = function(status) {
       showErrorModal(); 
       btnCancel.classList.add('disable')
      };
    sendHttpRequest('/scan/cancelScan', 'POST', null, successCallback, failCallback, false);  
  
}
function isOnDesiredScreen(screenTitle) {
  const desiredTitle = screenTitle; // Título esperado da tela
  return document.title === desiredTitle;
}

function sendRequestWithOutSpinner(xmlHttpRequest, body, successCallback, failCallback, tryAgainMethod){

  xmlHttpRequest.onreadystatechange = function(event) {
    if (xmlHttpRequest.readyState == XMLHttpRequest.DONE) {
        
        if (xmlHttpRequest.status == 200) { 
          successCallback(xmlHttpRequest.response); 
        }  
        if (xmlHttpRequest.status != 200) { 
          failCallback(xmlHttpRequest.status, xmlHttpRequest.response); 
        }
    }
  };

  try {
    xmlHttpRequest.send(body);
  } catch (error) {

    try { closeModal(); } catch (error) {}
    showConnectionLostError(tryAgainMethod);
  }
}

function getCurrentScreen(){
  var url_atual = window.location.href;
  url_atual = url_atual.split('/');
  return url_atual[getScreenNameIndex()];
}