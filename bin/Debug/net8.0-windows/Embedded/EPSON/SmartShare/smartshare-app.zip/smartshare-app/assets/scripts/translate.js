var translate;
function getLanguage() {
    var successCallback = function (response) { 
      var device = JSON.parse(response);
      var language = device.deviceCapabilities.settingLanguage;
      if (language == 'pt-BR')
        window.sessionStorage.setItem("translate", JSON.stringify(strings.pt));
      else if (language == 'en' || language == 'en-US')
        window.sessionStorage.setItem("translate", JSON.stringify(strings.en));
      else if (language == 'es' || language == 'es-MX')
        window.sessionStorage.setItem("translate", JSON.stringify(strings.es));
      else
        window.sessionStorage.setItem("translate", JSON.stringify(strings.pt));
    };
    var failCallback = function(status) { 
      window.sessionStorage.setItem("translate", JSON.stringify(strings.pt));
    };
    sendHttpRequest('/epson/getDeviceCapabilities', 'GET', null, successCallback, failCallback, true);  
}

function translateIndex(){
    translate = JSON.parse(window.sessionStorage.getItem('translate'));  
    document.getElementById("btn-advance").innerText = translate.next;
    document.getElementById("btn-back").innerText = translate.back;
}

function translateProcess(){
    getLanguage();
    translate = JSON.parse(window.sessionStorage.getItem('translate'));  
    
}

function translatePreview() {
  getLanguage();
  translate = JSON.parse(window.sessionStorage.getItem('translate'));  
}

function translateDocType() {
    translate = JSON.parse(window.sessionStorage.getItem('translate'));  
    var btnBackDocType = document.getElementById("btn-back");
    var btnSendToShare = document.getElementById("btn-advance");
    var noDocument = document.getElementById("no-items");
    document.getElementById("span-scanned").innerText = translate.docTyopeIsScanned;
    document.getElementById("span-published").innerText = translate.docTyopeIsPublished;
    document.getElementById("span-outdated").innerText = translate.docTyopeIsOutdated;
    btnBackDocType ? btnBackDocType.innerText = translate.back : "";
    btnSendToShare ? btnSendToShare.innerText = translate.publishToSmartShare : "";
    noDocument ? noDocument.innerText = translate.noItems1 + translate.documentoDocType.toLowerCase() + translate.noItems2 : "";

}

function translateIndexResult() {
  translate = JSON.parse(window.sessionStorage.getItem('translate'));  
  var noItems = document.getElementById("no-items");
  document.getElementById("btn-back").innerText = translate.back;
  noItems ? noItems.innerText = translate.noItems1 + translate.indexes.toLowerCase() + translate.noItems2 : "";
}

function translateScanSettings() {
  translate = JSON.parse(window.sessionStorage.getItem('translate'));

  document.getElementById("btn-scan").innerText = translate.buttonStartScan;
  document.getElementById("btn-back").innerText = translate.back;

  document.getElementById("two_sided-desc").innerText = translate.scanDuplex;
  document.getElementById("duplex-yes").innerText = translate.optScanYes;
  document.getElementById("duplex-no").innerText = translate.optScanNo;


  document.getElementById("resolution-desc").innerText = translate.scanResolution;
  document.getElementById("resolution-low").innerText = translate.optScanLow;
  document.getElementById("resolution-mid").innerText = translate.optScanMidium;
  document.getElementById("resolution-high").innerText = translate.optScanHigh;


  document.getElementById("size-desc").innerText = translate.scanSize;
  document.getElementById("size-a4").innerText = translate.optSizeA4;
  document.getElementById("size-letter").innerText = translate.optSizeLetter;
  document.getElementById("size-auto").innerText = translate.optSizeAuto;


  document.getElementById("color_mode-desc").innerText = translate.scanColorMode;
  document.getElementById("color-no").innerText = translate.optScanMono;
  document.getElementById("color-yes").innerText = translate.optScanColor;


  document.getElementById("orientation-desc").innerText = translate.scanOrientation;
  document.getElementById("rotation-no").innerText = translate.optScanPortrait;
  document.getElementById("rotation-yes").innerText = translate.optScanLandscape;


  document.getElementById("density-desc").innerText = translate.scanDensity;
  document.getElementById("density-low").innerText = translate.optScanLow;
  document.getElementById("density-mid").innerText = translate.optScanMidium;
  document.getElementById("density-high").innerText = translate.optScanHigh;
}

function translateLogin() {
  getLanguage();
  translate = JSON.parse(window.sessionStorage.getItem('translate'));
  var placeHolderUser = document.getElementById("input-user");
  placeHolderUser.setAttribute('placeholder', translate.userPlaceHolder);
  var placeHolderPwd = document.getElementById("input-pwd");
  placeHolderPwd.setAttribute('placeholder', translate.pwdPlaceHolder)
  document.getElementById("btn-advance").innerText = translate.next;
  document.getElementById("btn-back").innerText = translate.back;
}

function translateScanning(){
  getLanguage();
  translate = JSON.parse(window.sessionStorage.getItem('translate'));
  document.getElementById("digText").innerText = translate.scanDocument;
  document.getElementById("btn-cancel-scan").innerText = translate.cancelScanDocument;
}

function translateScanNewPage(){
  getLanguage();
  translate = JSON.parse(window.sessionStorage.getItem('translate'));
  document.getElementById("spanFinishScan").innerText = translate.finishScanning;
  document.getElementById("spanNewPage").innerText = translate.newPage;
  document.getElementById("spanCancelScan").innerText = translate.cancelScanDocument;
  document.getElementById("scanned-document").innerText = translate.scannedPage;
  document.getElementById("whatNow").innerText = translate.whatDoNow;
}

function translateDocSendSuccess(){
  getLanguage();
  translate = JSON.parse(window.sessionStorage.getItem('translate'));
  document.getElementById("btnDocSendSucContinue").innerText = translate.documentsSendedContinue;
  document.getElementById("btnNewProcess").innerText = translate.selectOtherProcess;
  document.getElementById("tex-doc-send-success").innerText = translate.documentsSended;
}
