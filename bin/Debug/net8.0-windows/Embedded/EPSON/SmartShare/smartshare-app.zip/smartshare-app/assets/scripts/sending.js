function initSend(){
    sendFiles();
}

function sendFiles() {
    var successCallback = function (response) { 
        navigateTo('doc-send-success.html');//TODO trocar para a tela que finaliza o processo e permite selecionar outro processo
    };
    var failCallback = function(status) { 
        showModalError(true, translate.scanNextActionErrorTitle, translate.scanNextActionErrorMsg, false, ""); 
    };

    sendHttpRequest('/process/send', 'GET', null, successCallback, failCallback, true);  
}
  