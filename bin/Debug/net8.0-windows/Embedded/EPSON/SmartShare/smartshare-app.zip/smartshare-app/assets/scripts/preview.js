var page = 0;
var maxPage;

function initPreview() {
  translatePreview();
  renderHeaderToPreview(translate.previewScan, true, true, true);
  btnNextPageToPreview();
  btnPreviousPageToPreview();
  try{
    getPage();
    hideSpinner();
  }catch(e){
    hideSpinner();
    showErrorModal();
  }
  
  
}
//REQUEST PARA O BACKEND PARA PEGAR O PREVIEW
function getPage() {
  showSpinner();
  var successCallback = function (response) {
      encodeImageFileAsURL(response);
      hideSpinner();
      updateButtonVisibility();  // Atualiza a visibilidade dos botões com base em `page` e `maxPage`
      pageStatus();
  };
  var failCallback = function (status) {
      if (page > 0) page--;  // Garante que a página não vá abaixo de 0
      updateButtonVisibility();
      hideSpinner();
      if (status == 404)
          showConnectionLostError("");
      if (status == 401)
          showInvalidLoginError();
      else
      showPreviewModal(translate.modalTitlePreview, translate.modalMessagePreview);
  };
  sendHttpRequestToPreview("/preview/getImage", "GET", null, successCallback, failCallback, null, page);
}
//DELETAR PÁGINA
function deletePage() {
  showSpinner();
  var successCallback = function (response) {
    hideSpinner();
    navigateTo("doc-type.html")
    updateButtonVisibility();  // Atualiza a visibilidade dos botões com base em `page` e `maxPage`
    pageStatus();
  };
  var failCallback = function (status) {};
  sendHttpRequestToPreview("/preview/removePage", "POST", null, successCallback, failCallback, null, page + 1);
}
//DECRIPTOGRAFAR A IMAGEM VINDA DO BACKEND
function encodeImageFileAsURL(data) {
  var response = JSON.parse(data);
  var src = "data:image;base64," + response.image;
  var imgPreview = document.getElementById("img-preview");
  imgPreview.setAttribute("src", src);

  maxPage = response.totalPages; // Atualiza o número máximo de páginas
  updateButtonVisibility(); // Chama após definir maxPage para atualizar os botões corretamente
}
//ATUALIZA A VIZIBILIDADE DO BOTÃO DE PAGINAÇÃO
function updateButtonVisibility() {
  var btnNext = document.getElementById("btn-next");
  var btnPrev = document.getElementById("btn-prev");
  btnNext.hidden = (page >= maxPage - 1); // Oculta o botão 'Próxima' se estiver na última página
  btnPrev.hidden = (page <= 0);          // Oculta o botão 'Anterior' se estiver na primeira página
}

function nextPagePreview() {
  if (page < maxPage - 1) {
      page++;
      getPage();
  }
}

function previousPagePreview() {
  if (page > 0) {
      page--;
      getPage();
  }
}

//CRIAÇÃO DE BOTÃO DA PAGINAÇÃO (AVANÇAR)
function btnNextPageToPreview(){
  var content = document.getElementById('content');
  var divBtnRight = document.createElement('div');
  divBtnRight.classList.add('controls-right');
  divBtnRight.id = 'btn-next';
  divBtnRight.hidden = true;  // Inicialmente oculto

  var btnNextPage = document.createElement('button');
  btnNextPage.classList.add('btnNextPage');
  btnNextPage.id = 'btn-next';
  btnNextPage.setAttribute('onmouseup', 'nextPagePreview()');

  var imgBtnNext = document.createElement('img');
  imgBtnNext.setAttribute('src', './assets/imgs/next-page.png');

  btnNextPage.appendChild(imgBtnNext);
  divBtnRight.appendChild(btnNextPage);
  content.appendChild(divBtnRight);
}
//CRIAÇÃO DE BOTÃO DA PAGINAÇÃO (VOLTAR)
function btnPreviousPageToPreview(){
  var content = document.getElementById('content');
  var divBtnLeft = document.createElement('div');
  divBtnLeft.classList.add('controls-left');
  divBtnLeft.id = 'btn-prev';
  divBtnLeft.hidden = true;  // Inicialmente oculto

  var btnPreviousPage = document.createElement('button');
  btnPreviousPage.classList.add('btnPreviousPage');
  btnPreviousPage.setAttribute('onmouseup', 'previousPagePreview()');

  var imgBtnPrevious = document.createElement('img');
  imgBtnPrevious.setAttribute('src', './assets/imgs/previous-page.png');

  btnPreviousPage.appendChild(imgBtnPrevious);
  divBtnLeft.appendChild(btnPreviousPage);
  content.appendChild(divBtnLeft);
}

function pageStatus(){
  var content = document.getElementById('content');
  var divPageStatus = document.getElementById('page-status');

  if (!divPageStatus) {
      divPageStatus = document.createElement('div');
      divPageStatus.className = 'page-status';
      divPageStatus.id = 'page-status';
      content.appendChild(divPageStatus);
  }

  var spanStatus = divPageStatus.querySelector('span');
  if (!spanStatus) {
      spanStatus = document.createElement('span');
      divPageStatus.appendChild(spanStatus);
  }
  
  spanStatus.textContent = (page + 1) + '/' + maxPage;
}
