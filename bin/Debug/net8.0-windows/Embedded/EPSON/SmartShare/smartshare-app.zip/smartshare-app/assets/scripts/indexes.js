var indexes;

function initIndexes() {
    renderFooter(true, "backToProcess(true)", true, "listIndexResult()", false, null);
    translateIndex();
    renderHeader(translate.informProcessData, true, true);
    renderPagination(appendIndexesItems);
    renderListOfIndexes();
    renderPagination(appendIndexesItems);


}

function renderListOfIndexes() {
    var mainProcessInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
    indexes = mainProcessInfo.indexes;

    if (indexes != null) {
        listitems = indexes.lstIndex;
        updateListPage(appendIndexesItems);
    } else {
        showNoItems(translate.indexes);
    }
}

function appendIndexesItems(listIndexes) {
    if (listIndexes.length < 1) {
        showNoItems(translate.indexes);
    } else {
        for (i in listIndexes) {
            var info = listIndexes[i];
            var content = document.getElementById("container");
            content.appendChild(addIndexItemOnScreen(info));
        }
    }
}

function addIndexItemOnScreen(index) {
    var divField = document.createElement("div");
    divField.setAttribute("id", "div-field-" + index.cdIndex);
    divField.classList.add("div-field");    

    divField.appendChild(createInputByIndex(index));

    if (index.required) {
        var required = document.createElement("div");
        required.innerHTML = "*";
        required.classList.add("required");

        divField.appendChild(required);
    }

    return divField;
}

function createInputByIndex(index) {
    var idxField = document.createElement("input");
    idxField.setAttribute("id", index.cdIndex);
    idxField.setAttribute("value", index.value);    
    idxField.setAttribute("onchange", "onChangeIndex(this)");
    idxField.setAttribute("placeholder", index.dsIndex);
    idxField.classList.add("idx-field");
    idxField.required = index.required;

    if(index.regEx.length > 0)
        idxField.setAttribute("pattern", index.regEx);

    setInputValueType(index, idxField);//Define o tipo do valor do campo
    setInputType(index, idxField);//Define o tipo de preenchmento do campo

    return idxField;
}

function setInputValueType(index, idxField) {
    switch(index.valueType) {
        case 1:
            //campo texto/numérico
            idxField.setAttribute("type", "text");
            break;
        case 2:
            //campo numérico
            idxField.setAttribute("type", "number");
            break;
        case 3:
            //Campo data            
            idxField.setAttribute("type", "text");
            idxField.readOnly = true;
            idxField.setAttribute("onmouseup", "initCalendar(this)");
            break;
    }
}

function setInputType(index, idxField) {
    switch(index.localType) {
        case 1:
        case 4:
            idxField.readOnly = true;
            idxField.setAttribute("type", "text");//Tem que ser do tipo texto, senão pode quebrar
            idxField.setAttribute("onmouseup", "intiSelectModal(this)");
            break;
        default:
            break;
    }
}

function onChangeIndex(idx) {
    validateRequired(idx, idx.id);
    validateRegEx(idx.value, idx.pattern, idx.id);

    for (i in indexes.lstIndex) {
        var index = indexes.lstIndex[i];

        if (index.cdIndex.toString().localeCompare(idx.id) == 0) {
            index.value = idx.value;
            break;
        }
    }
}

function listIndexResult() {
    if(validateIndexes()){
        var processInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
        processInfo.indexes = indexes;
        window.sessionStorage.setItem("mainProcessInfo", JSON.stringify(processInfo));
        listIndexesResult(indexes);
    }   
}

function validateIndexes() {
    var requiredError = false;
    var invalidRegex = false;
    for (i in indexes.lstIndex) {
        var index = indexes.lstIndex[i];

        if (validateRequired(index, index.cdIndex))
            requiredError = true;
        if (!validateRegEx(index.value, index.regEx, index.cdIndex))
            invalidRegex = true;
    }

    if (requiredError)
        showAlertModal(translate.requiredFieldsTitle, translate.requiredFieldsMsg);
    if (invalidRegex)
        showAlertModal(translate.invalidRegex, translate.invalidRegexMsg);

    return !(requiredError || invalidRegex);
}

function applyInvalidStyle(idxId, texmes) {
    var divField = document.getElementById("div-field-" + idxId);
	var message = document.getElementById("invalid-message-" + idxId);
    if (divField != undefined && message == undefined) {
        var idxField = divField.children[0];
        idxField.classList.add("invalid");

        message = document.createElement("div")
		message.setAttribute("id", "invalid-message-" + idxId);
        message.innerHTML = texmes;
        message.classList.add("idx-field-message");

        divField.appendChild(message);
    }
}

function removeInvalidStyle(idxId) {
    var divField = document.getElementById("div-field-" + idxId);
	var message = document.getElementById("invalid-message-" + idxId);
    if (divField != undefined) {
        var idxField = divField.children[0];
        idxField.classList.remove("invalid");		

		if (message != undefined) {
			divField.removeChild(message);
		}
    }
}

function validateRequired(index, id) {
    var isInvalid = index.required && index.value.length == 0;
    if (isInvalid) {
        //Indice obrigatório
        applyInvalidStyle(id, translate.invalidRegexIndex);
    } else {
        removeInvalidStyle(id);
    }

    return isInvalid;
}

function validateRegEx(value, pattern, id) {
    if (pattern.length > 0 && value.length > 0) {
        var regex = new RegExp(pattern);
        var test = regex.test(value);
        if (!test)
			applyInvalidStyle(id, translate.validateRegexIndex);
        else
			removeInvalidStyle(id);

        return test;
    } else {
        return true;
    }
}

function intiSelectModal(field) {
    for(i in indexes.lstIndex) {
        var index = indexes.lstIndex[i];
        if (index.cdIndex.toString().localeCompare(field.id) == 0) {
            if (index.localType == 1)
                initUniqueSelect(field, index);
            else
                initMultiSelect(field, index);
            break;
        }
    }
}
