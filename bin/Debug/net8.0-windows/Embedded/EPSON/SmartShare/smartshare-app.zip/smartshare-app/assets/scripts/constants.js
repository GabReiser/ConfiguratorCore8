function renderHeader(text, logout, logoShare){
    var header = document.createElement('div');
    header.classList.add('header');
    header.setAttribute('id', 'header')

    var h3 = document.createElement('h3');
    h3.setAttribute('id', 'txt-header');
    h3.classList.add('h3-header');
    h3.innerHTML = text;

    if(logout){
        var logoutBtn = document.createElement('button');
        logoutBtn.classList.add('logout-icon')
        logoutBtn.setAttribute('onmouseup', 'goToHomeDevice()');

        var imgExit = document.createElement('img');
        imgExit.classList.add('img-logout');
        imgExit.setAttribute('width', '24px');
        imgExit.setAttribute('src', './assets/imgs/exit-regular-24.png')

        logoutBtn.appendChild(imgExit);

        header.appendChild(logoutBtn);
    }
    if(logoShare){
        var logoShare = document.createElement('img');
        logoShare.classList.add('logo-share');
        logoShare.setAttribute('width', '24px');
        logoShare.setAttribute('src', './assets/imgs/logo-only.png')

        header.appendChild(logoShare);
    }

    var divbody = document.getElementById('divBody');

    header.appendChild(h3);
    divbody.appendChild(header);

    document.body.appendChild(divbody)
}

function renderHeaderToPreview(text, logout, logoShare, backToDocType){
    var header = document.createElement('div');
    header.classList.add('header-preview');
    header.setAttribute('id', 'header')

    var h3 = document.createElement('h3');
    h3.setAttribute('id', 'txt-header-preview');
    h3.classList.add('h3-header-preview');
    h3.innerHTML = text;

    if(logout){
        var logoutBtn = document.createElement('button');
        logoutBtn.classList.add('logout-icon-preview')
        logoutBtn.setAttribute('onmouseup', 'deletePage()');

        var imgExit = document.createElement('img');
        imgExit.classList.add('img-logout-preview');
        imgExit.setAttribute('width', '24px');
        imgExit.setAttribute('src', './assets/imgs/trash.png')

        logoutBtn.appendChild(imgExit);

        header.appendChild(logoutBtn);
    }
    if(backToDocType){
    var backToDocType = document.createElement('img');
    backToDocType.classList.add('back-doctype-preview');
    backToDocType.setAttribute('width', '24px');
    backToDocType.setAttribute('src', './assets/imgs/previous-preview.png')
    backToDocType.setAttribute('onmouseup', 'navigateTo("doc-type.html")');

    header.appendChild(backToDocType);
    }
    if(logoShare){
        var logoShare = document.createElement('img');
        logoShare.classList.add('logo-share-preview');
        logoShare.setAttribute('width', '24px');
        logoShare.setAttribute('src', './assets/imgs/logo-only.png')

        header.appendChild(logoShare);
    }

    var divbody = document.getElementById('divBody');

    header.appendChild(h3);
    divbody.appendChild(header);

    document.body.appendChild(divbody)
}


function renderFooter(hasBtnBack, backTo, hasBtnGo, goTo, searchBox, appendItems){
    var screenName = getCurrentScreen();

    var divbody = document.getElementById('divBody');

    var footer = document.createElement("div");
    footer.setAttribute("class", "bg-footer");
    footer.setAttribute("id", "div-footer");
    
    var divBtn = document.createElement('div');
    divBtn.classList.add('div-btn');

    if(hasBtnBack){
        var btnBack = document.createElement('button');
        btnBack.classList.add('btn-back');
        btnBack.setAttribute('id', 'btn-back');
        btnBack.setAttribute('onmouseup', backTo);
        btnBack.innerHTML = "Voltar";
        divBtn.appendChild(btnBack);
    }

    if (hasBtnGo){
        var btnNext = document.createElement('button');
        btnNext.classList.add('btn-advance');
        btnNext.setAttribute('id', 'btn-advance');
        btnNext.setAttribute('onmouseup', goTo);
        if(screenName === 'doc-type.html')
            btnNext.innerHTML = translate.publishToSmartShare;
        else{
            btnNext.innerHTML = "Avançar";
        }
        
        divBtn.appendChild(btnNext);
    }

    if(searchBox) {
       footer.appendChild(createSearchBox(appendItems));
    }

    footer.appendChild(divBtn);
    divbody.appendChild(footer);
}

function renderFooterToScanProperties(){
    var divbody = document.getElementById('divBody');

    var footer = document.createElement("div");
    footer.setAttribute("class", "bg-footer");
    footer.setAttribute("id", "div-footer");
    
    var divBtn = document.createElement('div');
    divBtn.classList.add('div-btn');

    var btnBack = document.createElement('button');
    btnBack.classList.add('btn-back');
    btnBack.setAttribute('id', 'btn-back');
    btnBack.setAttribute('onmouseup', "navigateTo('doc-type.html')");
    btnBack.innerHTML = "Voltar";
    divBtn.appendChild(btnBack);
    var btnScan = document.createElement('button');
    btnScan.classList.add('btn-scan');
    btnScan.setAttribute('id', 'btn-scan');
    btnScan.setAttribute('onmouseup', 'startScan()');
    btnScan.innerHTML = "Digitalizar";
    divBtn.appendChild(btnScan);

    //Refresh 
    var btnRefresh = renderRefreshFooterButton("resetSettings()");
    footer.appendChild(btnRefresh);    

    footer.appendChild(divBtn);
    divbody.appendChild(footer);
}

function renderRefreshFooterButton(method) {
    var button = document.createElement("button");
    button.setAttribute("id", "btn-refresh");
    button.setAttribute("class", "btn-refresh");
    button.setAttribute("onmouseup", method);

    return button;
}

function btnNextPage(appendItems){
    var content = document.getElementById('content');

    var divBtnRight = document.createElement('div');
    divBtnRight.classList.add('controls-right');
    divBtnRight.setAttribute('id', 'btn-next');

    var btnNextPage = document.createElement('button');
    btnNextPage.classList.add('btnNextPage');
    btnNextPage.setAttribute('onmouseup', 'nextPage(' + appendItems + ')');

    var imgBtnNext = document.createElement('img');
    imgBtnNext.setAttribute('src', './assets/imgs/next-page.png')

    btnNextPage.appendChild(imgBtnNext);

    divBtnRight.appendChild(btnNextPage);
    content.appendChild(divBtnRight);
}

function btnPreviousPage(appendItems){
    var content = document.getElementById('content');

    var divBtnLeft = document.createElement('div');
    divBtnLeft.classList.add('controls-left');
    divBtnLeft.setAttribute('id', 'btn-prev');
    divBtnLeft.hidden = true;

    var btnPreviousPage = document.createElement('button');
    btnPreviousPage.classList.add('btnPreviousPage');
    btnPreviousPage.setAttribute('onmouseup', 'previousPage(' + appendItems + ')');

    var imgBtnPrevious = document.createElement('img');
    imgBtnPrevious.setAttribute('src', './assets/imgs/previous-page.png')

    btnPreviousPage.appendChild(imgBtnPrevious);

    divBtnLeft.appendChild(btnPreviousPage);
    content.appendChild(divBtnLeft);
}

function createSearchBox(appendItems) {
    var screenName = getCurrentScreen();
    var searchBox = document.createElement("div");
    searchBox.setAttribute("class", "search-box");
    

    var img = document.createElement("img");
    

    var searchText = document.createElement("input");
    searchText.setAttribute("id", "search");
    searchText.setAttribute("type", "text");
    searchText.setAttribute("onfocus", "expandSearch()");
    searchText.setAttribute("onchange", "searchOnList(" + appendItems + ")");

    if (screenName=="doc-type.html"){
        searchBox.setAttribute("id", "search-box-doc-type");
        searchBox.setAttribute("class", "search-box-doc-type");
        searchText.setAttribute("class", "search-doc-type");
        img.setAttribute("class", "search-img-doc-type");
    } else {
        img.setAttribute("id", "search-img");
        img.setAttribute("class", "search-img");
        searchText.setAttribute("class", "search");
    }

    searchBox.appendChild(img);
    searchBox.appendChild(searchText);

    return searchBox;
}

function isLocalEnvironment() {
    var hostname = window.location.hostname;
    return hostname === 'localhost' || hostname.indexOf('127.') === 0 || hostname.indexOf('192.168.') === 0;
  }
  
  function getScreenNameIndex() {
    return isLocalEnvironment() ? 3 : 4;
  }

function getCurrentScreen(){
    var url_atual = window.location.href;
    url_atual = url_atual.split('/');
    return url_atual[getScreenNameIndex()];
}