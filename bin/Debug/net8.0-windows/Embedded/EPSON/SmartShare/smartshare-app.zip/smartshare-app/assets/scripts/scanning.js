function initScanning(){
    verifyErrorScanning();
    translateScanning();
}

function verifyErrorScanning() {
    var queryString = window.location.search.slice(1);
    if (queryString == 'abortedScan')
        showScanError("navigateTo('scan-properties.html');");
  }  