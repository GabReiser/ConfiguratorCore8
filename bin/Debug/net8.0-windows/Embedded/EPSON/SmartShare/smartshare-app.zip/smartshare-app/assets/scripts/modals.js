function showErrorModal() {
    var modalBox = creatModalBox(true, false, "closeModal(this.parentNode)");
    var mainModal = modalBox.children[0];
    mainModal.children[0].innerHTML = translate.modalErrorTitle;//título
    mainModal.children[1].innerHTML = translate.modalErrorMessage;//mensagem
    mainModal.children[2].innerHTML = translate.modalErrorBtn;//botão principal

    document.body.appendChild(modalBox);
}

function showScanError(backToScanProperties) {
    var modalBox = creatModalBox(true, false, backToScanProperties);
    var mainModal = modalBox.children[0];
    mainModal.children[0].innerHTML = translate.scanErrorTitle;//título
    mainModal.children[1].innerHTML = translate.scanErrorMessage;//mensagem
    mainModal.children[2].innerHTML = translate.scanErrorBtn;//botão principal

    document.body.appendChild(modalBox);
}

function showConnectionLostError(tryAgainMethod) {
    var modalBox = creatModalBox(false, false, tryAgainMethod);
    var mainModal = modalBox.children[0];
    mainModal.children[0].innerHTML = translate.connectionLostErrorTitle;//título
    mainModal.children[1].innerHTML = translate.connectionLostErrorMessage;//mensagem
    mainModal.children[2].innerHTML = translate.connectionLostErrorBtn;//botão principal

    document.body.appendChild(modalBox);
}

function showInvalidLoginError() {
    var modalBox = creatModalBox(true, false, "closeModal(this.parentNode)");
    var mainModal = modalBox.children[0];
    mainModal.children[0].innerHTML = translate.invalidLoginTitle;//título
    mainModal.children[1].innerHTML = translate.invalidLoginMessage;//mensagem
    mainModal.children[2].innerHTML = translate.invalidLoginBtn;//botão principal

    document.body.appendChild(modalBox);
}

function showQuestionModal(primaryBtnMethod) {
    var modalBox = creatModalBox(false, true, primaryBtnMethod);
    var mainModal = modalBox.children[0];
    mainModal.children[0].innerHTML = translate.questionModalTitle;//título
    mainModal.children[1].innerHTML = translate.questionModalMessage;//mensagem
    mainModal.children[2].innerHTML = translate.questionModalBtn;//botão principal

    document.body.appendChild(modalBox);
}

function showPreviewModal(title, message) {
    var modalBox = creatModalBox(false, false, "closeModal(this.parentNode)");
    var mainModal = modalBox.children[0];
    mainModal.children[0].innerHTML = title;//título
    mainModal.children[1].innerHTML = message;//mensagem
    mainModal.children[2].innerHTML = translate.modalErrorBtn;//botão principal

    document.body.appendChild(modalBox);
}

function showAlertModal(title, message) {
    var modalBox = creatModalBox(false, false, "closeModal(this.parentNode)");
    var mainModal = modalBox.children[0];
    mainModal.children[0].innerHTML = title;//título
    mainModal.children[1].innerHTML = message;//mensagem
    mainModal.children[2].innerHTML = translate.modalErrorBtn;//botão principal

    document.body.appendChild(modalBox);
}

function creatModalBox(errorIcon, showSecondaryBtn, primaryBtnMethod) {
    var modalBox = document.createElement("div");
    modalBox.setAttribute("id", "modal-box");
    modalBox.classList.add("modal-box");

    var mainModal = document.createElement("div");
    mainModal.classList.add("main-modal");

    var title = document.createElement("h2");
    title.classList.add("title");
    mainModal.appendChild(title);

    var msg = document.createElement("span");
    msg.classList.add("message");
    mainModal.appendChild(msg);

    var primaryBtn = document.createElement("button");
    primaryBtn.classList.add("primary-btn");
    primaryBtn.setAttribute("onmouseup", primaryBtnMethod);
    mainModal.appendChild(primaryBtn);    

    var icon = document.createElement("img");
    icon.classList.add("icon");
    if (errorIcon)
        icon.setAttribute("src", "./assets/imgs/error.png");
    else
        icon.setAttribute("src", "./assets/imgs/warning.png");

    mainModal.appendChild(icon);    

    if (showSecondaryBtn) {
        var secondaryBtn = document.createElement("button");
        secondaryBtn.classList.add("secondary-btn");
        secondaryBtn.setAttribute("onmouseup", "closeModal(this.parentNode)");
        secondaryBtn.innerText = translate.cancel;
        mainModal.appendChild(secondaryBtn);
    }


    modalBox.appendChild(mainModal);

    return modalBox;
}

function closeModal(child) {
    var modal;
    if(child != null) {
        modal = child.parentNode;
    } else {
        modal = document.getElementById("modal-box");
    }
    
    document.body.removeChild(modal);
}

function createButton(text, imgSrc, onClickFunction, doc) {
    var button = document.createElement('button');
    button.id = doc;
    button.className = "modal-button"
    var img = document.createElement('img');
    img.src = imgSrc;
    var buttonText = document.createElement('span');
    buttonText.textContent = text;
    button.appendChild(img);
    button.appendChild(buttonText);
    button.addEventListener('mouseup', onClickFunction);
    return button;
}

function openDocTypeModal(doc) {
    var docTypeContainer = document.getElementById('container');

    var overlay = document.createElement('div');
    overlay.classList.add('overlay');
    overlay.id = 'overlay';
    overlay.addEventListener('mouseup', closeModalDocType);
    docTypeContainer.appendChild(overlay);

    var divModal = document.createElement('div');
    divModal.classList.add('modal-docType');
    divModal.id = 'modal-docType';
    
    var buttonsData = [
        { text: translate.preveiwDocType, imgSrc: './assets/imgs/eye.png', onClickFunction: function() {goToPreview('preview.html');} },
        { text: translate.scanAgainDocType, imgSrc: './assets/imgs/file-upload.png', onClickFunction: function() { goToScanSettings(doc); } },
        { text: translate.deleteDocType, imgSrc: './assets/imgs/delete.png', onClickFunction: function() { deleteScan(); } }
    ];

    buttonsData.forEach(function(buttonData) {
        var button = createButton(buttonData.text, buttonData.imgSrc, buttonData.onClickFunction, doc);
        divModal.appendChild(button);
    });

    docTypeContainer.appendChild(divModal);
}


function closeModalDocType() {
   var divModal = document.getElementById('modal-docType');
   var overlay = document.getElementById('overlay');
   overlay.remove();
   divModal.remove();

}

function docTypeModal(doc){
    var divBtn = document.getElementById('container');
    
    var threeDots = document.createElement('button')
    threeDots.classList.add('modal-doc-type');
    threeDots.setAttribute("id", doc.idtd);
    threeDots.setAttribute("onmouseup", 'openDocTypeModal('+ doc.idtd + ')');
 

    var imgDots = document.createElement('img');
    imgDots.setAttribute("src", "./assets/imgs/threeDotsBlack.png");

    threeDots.appendChild(imgDots);
    divBtn.appendChild(threeDots);
}