var indexResult;

function initIndexResult(){
    renderFooter(true, "navigateTo('indexes.html')", false, "", true, appendIndexesResultItems);
    translateIndexResult();
    renderHeader(translate.informProcessData, true, true);
    renderListOfIndexesResult();
    renderPagination(appendIndexesResultItems);

}

function renderListOfIndexesResult() {
    var mainProcessInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
    indexResult = mainProcessInfo.indexResult;

    if (indexResult != null) {
        listitems = indexResult.itemValidationList;
        updateListPage(appendIndexesResultItems);
    } else {
        showNoItems(translate.indexes);
    }
}

function appendIndexesResultItems(listIndexes) {
    if (listIndexes.length < 1) {
        showNoItems(translate.indexes);
    } else {
        for (i in listIndexes) {
            var info = listIndexes[i];
            var content = document.getElementById("container");
            content.appendChild(addProcessItemOnScreen(info));
        }
    }
}

function addProcessItemOnScreen(indexResult) {
    var btnProcess = document.createElement("button");
    btnProcess.setAttribute("id", indexResult.id);
    if (indexResult.text.length > this.MAX_LENGTH)
        btnProcess.innerHTML = indexResult.text.substring(0, this.MAX_LENGTH) + "...";
    else
        btnProcess.innerHTML = indexResult.text;

    btnProcess.setAttribute("class", "btn-index-result");
    btnProcess.setAttribute("onmouseup", "selectIndexResult(this);");

    return btnProcess;
}

function selectIndexResult(btnIndexResult) {
    listDocumentsType(getIndexResult(btnIndexResult.id));
}

function getIndexResult(id) {
    for (i in indexResult.itemValidationList){
        var resultSelected = indexResult.itemValidationList[i];
        if(resultSelected.id == id){
            var indexResultInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
            indexResultInfo.resultSelected = resultSelected;
            window.sessionStorage.setItem("mainProcessInfo", JSON.stringify(indexResultInfo));
            return resultSelected;
        }
    }
}
