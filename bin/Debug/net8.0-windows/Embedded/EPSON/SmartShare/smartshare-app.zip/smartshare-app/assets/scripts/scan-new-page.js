var nextAction = {
    'scan_query': 'continuation',
    'answer': 'no'
}

function initScanNewPage() {
    translateScanNewPage();
}

function finishScanning(){
    newPage(false);
}

function newPage(pAnswer){
    nextAction.answer = pAnswer ? 'yes' : 'no';

    var successCallback = function (response) { 
        if(pAnswer)
            navigateTo('scanning.html');
    };
    var failCallback = function(status) { 
        showModalError(true, translate.scanNextActionErrorTitle, translate.scanNextActionErrorMsg, false, ""); 
    };

    sendHttpRequest('/scan/nextAction', 'POST', JSON.stringify(nextAction), successCallback, failCallback, true);  
}

function cancelScanning(){ 

    //chamada servidor excluir scan
    var successCallback = function (response) { newPage(false); };
    var failCallback = function(status) { showModalError(true, translate.scanCancelErrorTitle, translate.scanCancelErrorMsg, false, ""); };
    sendHttpRequest('/scan/cancelScan', 'POST', null, successCallback, failCallback, false);
    
}


  