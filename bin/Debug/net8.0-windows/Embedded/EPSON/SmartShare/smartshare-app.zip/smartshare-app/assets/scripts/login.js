function initLogin(){
    renderFooter(true, "backToProcess(false);", true, "sendLogin();", false, false);
    translateLogin();
    renderHeader(translate.loginHeader, true, true);

  
}

function getInputs(){

    var user = document.getElementById("input-user");
        const userValue = user.value;
    var pwd = document.getElementById("input-pwd");
        const pwdValue = pwd.value;

    var jsonUser = "{\"userLogin\": \"" + userValue + "\", \"password\": \"" + pwdValue + "\"}";

    return jsonUser;
}