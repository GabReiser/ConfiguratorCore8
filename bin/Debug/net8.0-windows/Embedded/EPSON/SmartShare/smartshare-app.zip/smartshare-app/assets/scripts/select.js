MAX_LENGTH_OPT = 25;

var fieldSelect;
var selectPerPage = 4;
var selectState = { page: 1 }
var selectFilter;
var optionsList;
var optionsListFilter;
var isMultiSelect;


function initUniqueSelect(field, optList) {
    fieldSelect = field;
    optionsList = optList.indexesValue;
    selectFilter = undefined;
    isMultiSelect = false;

    createBoxUniqueSelect();

    updateOptionListPage();
}

function createBoxUniqueSelect() {
    var boxUniqueSelect = document.createElement("div");
    boxUniqueSelect.setAttribute("id", "modal-unique-select");
    boxUniqueSelect.classList.add("modal-box");

    boxUniqueSelect.innerHTML = "<div id='unique-select' class='modal-select'>\
                                    <div class='header-select'>\
                                        <span id='header-select-title' class='header-select title'>Escolha uma opção</span>\
                                        <button id='prev' onmouseup='prevOptList()' class='pagination prev'></button>\
                                        <button id='next' onmouseup='nextOptList()' class='pagination next'></button>\
                                        <button id='close' onmouseup='closeUniqueSelect()' class='pagination close'></button>\
                                    </div>\
                                    <div id='options-list' class='options-list'>\
                                    </div>\
                                    <div class='select-footer'>\
                                        <div class='search-box'>\
                                            <img id='search-img' class='search-img'>\
                                            <input id='search' type='text' class='search' onfocus='expandSearch()' onchange='searchOptions()'>\
                                        </div>\
                                    </div>\
                                </div>";

    document.body.appendChild(boxUniqueSelect);
}

function initMultiSelect(field, optList) {
    fieldSelect = field;
    optionsList = optList.indexesValue;
    selectFilter = undefined;
    isMultiSelect = true;

    createBoxMultSelect();

    updateOptionListPage();
}

function createBoxMultSelect() {
    var boxUniqueSelect = document.createElement("div");
    boxUniqueSelect.setAttribute("id", "modal-multi-select");
    boxUniqueSelect.classList.add("modal-box");

    boxUniqueSelect.innerHTML = "<div id='multi-select' class='modal-select'>\
                                    <div class='header-select'>\
                                        <span id='header-select-title' class='header-select title'>Escolha as opções</span>\
                                        <button id='prev' onmouseup='prevOptList()' class='pagination prev'></button>\
                                        <button id='next' onmouseup='nextOptList()' class='pagination next'></button>\
                                        <button id='close' onmouseup='closeMultiSelect()' class='pagination close'></button>\
                                    </div>\
                                    <div id='options-list' class='options-list'>\
                                    </div>\
                                    <div class='select-footer'>\
                                        <div class='search-box'>\
                                            <img id='search-img' class='search-img'>\
                                            <input id='search' type='text' class='search' onfocus='expandSearch()' onchange='searchOptions()'>\
                                        </div>\
                                        <button id='btn-ok' class='btn-ok' onmouseup='setValuesMultiSelect()'>OK</button>\
                                    </div>\
                                </div>";

    document.body.appendChild(boxUniqueSelect);
}


function nextOptList() {
	selectState.page++;
    var listRef = selectFilter == undefined ? optionsList : optionsListFilter;
	if (selectState.page > Math.ceil(listRef.length/selectPerPage)) {
	  selectState.page = 1;
	}
	
	updateOptionListPage();
}

function prevOptList() {
	selectState.page--;
    var listRef = selectFilter == undefined ? optionsList : optionsListFilter;
	if (selectState.page < 1) {
		selectState.page = Math.ceil(listRef.length/selectPerPage);
	}

	updateOptionListPage();
}

function updateOptionListPage() {
	var firstItem = (selectState.page - 1) * selectPerPage;
	var lastItem = firstItem + selectPerPage;

    var paginatedItemsList = [];

    if (selectFilter == undefined)
      paginatedItemsList = optionsList.slice(firstItem, lastItem);
    else
      paginatedItemsList = optionsListFilter.slice(firstItem, lastItem);

	appendOptionsItems(paginatedItemsList);
}

function appendOptionsItems(list) {
    var optList = document.getElementById("options-list");
    optList.innerHTML = "";
    var ulOptLst = document.createElement("ul");

    for(i in list) {
        var opt = list[i];
        var liOpt = document.createElement("li");
        liOpt.setAttribute("id", opt.cdIndexValue);
        if (isMultiSelect)
            liOpt.setAttribute("onmouseup", "selectMultiOption(this)");
        else
            liOpt.setAttribute("onmouseup", "selectOption(this)");

        liOpt.innerText = opt.value.length > MAX_LENGTH_OPT ? 
                          opt.value.substring(0, MAX_LENGTH_OPT) + "..." : 
                          opt.value;

        if(opt.selected)
            liOpt.classList.add("active");

        ulOptLst.appendChild(liOpt);
    }

    optList.appendChild(ulOptLst);
}

function selectOption(optSelected) {
    var ulParent = optSelected.parentNode;
    var liOpt = ulParent.children;

    for(i=0; i<liOpt.length; i++) {
        //Remove a classe de todos os itens selecionados
        liOpt[i].classList.remove("active");
    }

    for (i in optionsList) {
        var opt = optionsList[i];
        if (opt.cdIndexValue == parseInt(optSelected.id)) {
            opt.selected = !opt.selected;
            if (opt.selected) {
                optSelected.classList.add("active");
                fieldSelect.value = opt.value;
            } else {
                optSelected.classList.remove("active");
                fieldSelect.value = "";
            }
        } else {
            opt.selected = false;
        }
    }

    fieldSelect.onchange();
    setTimeout(closeUniqueSelect, 300);
}

function selectMultiOption(optSelected) {
    for (i in optionsList) {
        var opt = optionsList[i];
        if (opt.cdIndexValue == parseInt(optSelected.id)) {
            if (!opt.selected) {
                opt.selected = true;
                //Adiciona a classe na opção selecionada
                optSelected.classList.add("active");
            } else {
                opt.selected = false;
                //Adiciona a classe na opção selecionada
                optSelected.classList.remove("active");
            }
        }
    }
}

function closeUniqueSelect() {
    var uniqueSelect = document.getElementById("modal-unique-select");
    document.body.removeChild(uniqueSelect);
}

function closeMultiSelect() {
    var multiSelect = document.getElementById("modal-multi-select");
    document.body.removeChild(multiSelect);
}

function searchOptions() {
    selectFilter = document.getElementById("search").value
    optionsListFilter = [];
    selectState.page = 1;
  
    for(i in optionsList) {
      if (optionsList[i].value.toLowerCase().indexOf(selectFilter.toLowerCase()) !== -1)
        optionsListFilter.push(optionsList[i]);
    }
  
    updateOptionListPage();
}

function setValuesMultiSelect() {
    fieldSelect.value = "";
    for (i in optionsList) {
        var opt = optionsList[i];

        if (opt.selected)
            fieldSelect.value += opt.value + "; ";
    }

    fieldSelect.onchange();

    setTimeout(closeMultiSelect, 300);
}