var months = [
    {
        "name": "Janeiro",
        "abrev": "Jan",
        "lastDay": 31
    },
    {
        "name": "Fevereiro",
        "abrev": "Fev",
        "lastDay": 28
    },
    {
        "name": "Março",
        "abrev": "Mar",
        "lastDay": 31
    },
    {
        "name": "Abril",
        "abrev": "Abr",
        "lastDay": 30
    },
    {
        "name": "Maio",
        "abrev": "Mai",
        "lastDay": 31
    },
    {
        "name": "Junho",
        "abrev": "Jun",
        "lastDay": 30
    },
    {
        "name": "Julho",
        "abrev": "Jul",
        "lastDay": 31
    },
    {
        "name": "Agosto",
        "abrev": "Ago",
        "lastDay": 31
    },
    {
        "name": "Setembro",
        "abrev": "Set",
        "lastDay": 30
    },
    {
        "name": "Outubro",
        "abrev": "Out",
        "lastDay": 31
    },
    {
        "name": "Novembro",
        "abrev": "Nov",
        "lastDay": 30
    },
    {
        "name": "Dezembro",
        "abrev": "Dez",
        "lastDay": 31
    }
]

var weekDays = [ 
    {
        "id": 0,
        "description": "Sunday",
        "abrv": "Dom"
    },
    {
        "id": 1,
        "description": "Mondey",
        "abrv": "Seg"
    },
    {
        "id": 2,
        "description": "Tuesday",
        "abrv": "Ter"
    },
    {
        "id": 3,
        "description": "Wednessday",
        "abrv": "Qua"
    },
    {
        "id": 4,
        "description": "Thursday",
        "abrv": "Qui"
    },
    {
        "id": 5,
        "description": "Friday",
        "abrv": "Sex"
    },
    {
        "id": 6,
        "description": "Saturday",
        "abrv": "Sab"
    },
    
]

var currDay = 1;
var currMonth = 0;
var currYear  = 2024;
var fieldDate;

var initYear;
var endYear;

function initCalendar(field) {
    fieldDate = field;
    parserDate(field.value);

    createBoxCalendar();

    updateCalendar(months[currMonth]);
}

function parserDate(date) {
    var dateArr;
    if (date.length > 0) {
        dateArr = date.split("/");
    } else {
        var date = new Date();
        var today = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
        dateArr = today.split("/");
    }
    
    currDay = parseInt(dateArr[0]);
    currMonth = parseInt(dateArr[1]) - 1;
    currYear = parseInt(dateArr[2]);
}

function createBoxCalendar() {
    var boxCalendar = document.createElement("div");
    boxCalendar.setAttribute("id", "modal-calendar");
    boxCalendar.classList.add("modal-box");

    boxCalendar.innerHTML = "<div id='calendar' class='modal-calendar'>\
                                <div class='header-calendar'>\
                                    <span id='year' class='year' onmouseup='showListYears()'></span>\
                                    <span id='month' class='month' onmouseup='listByMonth()'></span>\
                                    <button id='prev' onmouseup='prevMonth()' class='pagination prev'></button>\
                                    <button id='next' onmouseup='nextMonth()' class='pagination next'></button>\
                                </div>\
                                <div id='week' class='week'>\
                                </div>\
                                <div id='day' class='day'>\
                                </div>\
                                <div id='list-year' class='list-year' hidden></div>\
                                <div id='list-month' class='list-month' hidden></div>\
                            </div>";

    document.body.appendChild(boxCalendar);

}

function updateCalendar(month) {
    if (currYear%4 == 0)
        months[1].lastDay = 29;
    else
        months[1].lastDay = 28;

    document.getElementById("month").innerText = month.name;
    document.getElementById("year").innerText = currYear;
    showWeekDays();
    showDays(month);
}

function showWeekDays() {
    var week = document.getElementById("week");
    var ulwDays = document.createElement("ul");
    for (i=0; i<weekDays.length; i++) {
        var liwDays = document.createElement("li");
        liwDays.setAttribute("id", i);
        liwDays.innerText = weekDays[i].abrv;

        ulwDays.appendChild(liwDays);
    }

    week.innerHTML = "";
    week.appendChild(ulwDays);
}

function showDays(month) {
    var days = document.getElementById("day");
    var ulDays = document.createElement("ul");
    var initWeek = verifyInitWeek();

    for(i=initWeek; i<=month.lastDay; i++) {
        var liDays = document.createElement("li");
        if(i > 0) {
            liDays.setAttribute("id", i);
            liDays.setAttribute("onmouseup", "selectDay(this)");
            liDays.innerText = i;
            if(i == currDay)
                liDays.classList.add("active");
        }

        ulDays.appendChild(liDays);
    }
    days.innerHTML = "";
    days.appendChild(ulDays);
}

function nextMonth() {
    currMonth = currMonth + 1;

    if(currMonth > 11) {
        currMonth = 0;
        currYear = currYear + 1;
    }

    updateCalendar(months[currMonth]);
}

function prevMonth() {
    currMonth = currMonth - 1;

    if(currMonth < 0) {
        currMonth = 11;
        currYear = currYear - 1;
    }

    updateCalendar(months[currMonth]);
}

function prevListYears() {
    currYear = initYear;

    listYears();
}

function nextListYears() {
    currYear = endYear;

    listYears();
}

function verifyInitWeek() {
    var m = currMonth == 0 ? 13 : currMonth == 1 ? 14 : currMonth + 1;
    var y = m == 13 || m == 14 ? currYear - 1 : currYear;
    var d = 1

    var A = Math.floor(y/100);
    var B = Math.floor(A/4);
    var C = 2-A+B;

    var D = Math.floor(365.25*(y+4716));
    var E = Math.floor(30.6001*(m+1));

    var julianDay = D + E + d + C - 1524;

    var result = Math.floor(julianDay % 7);
    
    switch(result) {
        case 6:
            return 1;
        default:
            return -result;
    }
}

function selectDay(day) {
    var ulParent = day.parentNode;
    var liDays = ulParent.children;

    for(i=0; i<liDays.length; i++) {
        //Remove a classe de todos os itens selecionados
        liDays[i].classList.remove("active");
    }

    //Adiciona a classe na opção selecionada
    day.classList.add("active");

    fieldDate.value = getDateSelected(parseInt(day.id));
    fieldDate.onchange();

    setTimeout(function() {
        var calendar = document.getElementById("modal-calendar");
        document.body.removeChild(calendar);
    }, 300);
}

function getDateSelected(dayInt) {
    var day = dayInt < 10 ? "0" + dayInt : dayInt;
    var month = currMonth < 10 ? "0" + (currMonth + 1) : currMonth;
    var year = currYear

    return day + "/" + month + "/" + year;
}

function showListYears() {
    document.getElementById("week").hidden = true;
    document.getElementById("day").hidden = true;
    document.getElementById("month").hidden = true;
    document.getElementById("list-year").hidden = false;

    document.getElementById("next").setAttribute("onmouseup", "nextListYears()");
    document.getElementById("prev").setAttribute("onmouseup", "prevListYears()");

    listYears()
}

function listYears() {
    var divListYear = document.getElementById("list-year");
    initYear = currYear - 17;
    endYear = initYear + 34;
    var ulYears = document.createElement("ul");

    for(i=initYear; i<=endYear; i++) {
        var liYear = document.createElement("li");
        liYear.setAttribute("id", i);
        liYear.setAttribute("onmouseup", "selectYear(this)");
        liYear.innerText = i;
        if(currYear == i)
            liYear.classList.add("active");

        ulYears.appendChild(liYear);
    }
    divListYear.innerHTML = "";
    divListYear.appendChild(ulYears);

}

function selectYear(year) {
    currYear = parseInt(year.id);
    document.getElementById("list-year").hidden = true;    
    document.getElementById("month").hidden = false;

    document.getElementById("next").setAttribute("onmouseup", "nextMonth()");
    document.getElementById("prev").setAttribute("onmouseup", "prevMonth()");

    listMonth();
    document.getElementById("list-month").hidden = false;
}

function listMonth() {
    var divListMonth = document.getElementById("list-month");
    var ulMonth = document.createElement("ul");

    for(i=0; i<months.length; i++) {
        var liMonth = document.createElement("li");
        liMonth.setAttribute("id", i);
        liMonth.setAttribute("onmouseup", "selectMonth(this)");
        liMonth.innerText = months[i].abrev;
        if(currMonth == i)
            liMonth.classList.add("active");

        ulMonth.appendChild(liMonth);
    }
    divListMonth.innerHTML = "";
    divListMonth.appendChild(ulMonth);
}

function listByMonth() {
    document.getElementById("week").hidden = true;
    document.getElementById("day").hidden = true;

    listMonth();
    document.getElementById("list-month").hidden = false;
}

function selectMonth(month) {
    document.getElementById("list-month").hidden = true;
    document.getElementById("week").hidden = false;
    document.getElementById("day").hidden = false;

    currMonth = parseInt(month.id);

    updateCalendar(months[currMonth]);
}

