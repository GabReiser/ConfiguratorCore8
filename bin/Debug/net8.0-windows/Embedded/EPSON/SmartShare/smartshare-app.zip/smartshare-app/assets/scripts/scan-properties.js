var textHeader;
var settings;

const defaultSettings = {
    'color_mode': '0',
    'resolution': '1',
    'density': '-2',
    'size': '0',
    'orientation': '0',
    'two_sided': '0'
}

function initScanProperties(){

    renderFooterToScanProperties();
    translateScanSettings();
    renderHeader(translate.scanDocumentScanProperties + getDocTypeText(), true, true);
    settings = setDefalutValues();

}

function getDocTypeText(){
    var indexResultInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
    textHeader = indexResultInfo.docTypeSelected;
    return textHeader;
}

function changeOption(option) {
    var nodeParent = option.parentNode;//Div da Opção
    var nodeList = nodeParent.children;

    for(i=0; i<nodeList.length; i++) {
        if(i == 0) continue;//Descrição da Opção
        //Remove a classe de selecionado de todos os botões
        nodeList[i].classList.add("unselected");
        nodeList[i].classList.remove("selected");
    }

    //Adiciona a classe de selecionado na opção selecionada
    option.classList.remove("unselected");
    option.classList.add("selected");

    updateValueSelected(nodeParent.id, option.value);
}

function updateValueSelected(divName, optValue) {
    settings[divName] = optValue;
    console.log(optValue);
}

function resetSettings() {
    var content = document.getElementById("content");

    for(i=0; i<content.children.length; i++) {
        var divOpt = content.children[i];//Div da Opção
        var nodeList = divOpt.children;
        for(j=0; j<nodeList.length; j++) {
            if(j == 0) continue;//Descrição da Opção
            if(j == 1){//Primeiro botão à esquerda (Valor padrão)
                nodeList[j].classList.add("selected");
                nodeList[j].classList.remove("unselected");
            }
            else{//Os outros botões
                nodeList[j].classList.remove("selected");
                nodeList[j].classList.add("unselected");
            }
        }
    }

    settings = setDefalutValues();
}

function setDisableBtns(duplex, res, tamanho, color, orient, densit){
    if(duplex){
    //DUPLEX
        var twoSided = document.getElementById('two_sided');
        twoSided.classList.add('disable');
    }else{
        var twoSided = document.getElementById('two_sided');
        twoSided.classList.remove('disable');
    }
    if(res){
    //RESOLUTION
        var resolution = document.getElementById('resolution');
        resolution.classList.add('disable');
    }
    if(tamanho){
    //SIZE
        var size = document.getElementById('size');
        size.classList.add('disable');
    }
    if(color){
    //COLOR
        var colorMode = document.getElementById('color_mode');
        colorMode.classList.add('disable');
    }
    if(orient){
    //ORIENTATION
        var orientation = document.getElementById('orientation');
        orientation.classList.add('disable');
    }
    if(densit){
    //DENSITY
        var density = document.getElementById('density');
        density.classList.add('disable');
    }

}
 
function setDefalutValues() {
    var scanSettings = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
    var content = document.getElementById("content");
    try{
        if(scanSettings.scanSettings.canChangeAll == 0){
            setDisableBtns(true, true, true, true, true, true);
            
        }if(scanSettings.scanSettings.canChangeDuplex == 1){
            setDisableBtns(false);
        }
        
        var setSettings = {
            'color_mode': scanSettings.scanSettings.defaultSettings.color_mode,
            'resolution': scanSettings.scanSettings.defaultSettings.resolution,
            'density': scanSettings.scanSettings.defaultSettings.density,
            'size': scanSettings.scanSettings.defaultSettings.size,
            'orientation': scanSettings.scanSettings.defaultSettings.orientation,
            'two_sided': scanSettings.scanSettings.defaultSettings.two_sided
        }
        for (var i = 0; i < content.children.length; i++) {
            var divOpt = content.children[i]; // Div da Opção
            var groupName = divOpt.id; // Nome do grupo de opções
    
            if (scanSettings.scanSettings.defaultSettings && scanSettings.scanSettings.defaultSettings[groupName]) {
                var valueToSet = scanSettings.scanSettings.defaultSettings[groupName];
    
                var nodeList = divOpt.children;
                for (var j = 0; j < nodeList.length; j++) {
                    if (j === 0) continue; // Descrição da Opção
                    var button = nodeList[j];
                    if (button.value === valueToSet) {
                        button.classList.add("selected");
                        button.classList.remove("unselected");
                    } else {
                        button.classList.remove("selected");
                        button.classList.add("unselected");
                    }
                }
            }
        }
        return setSettings;
    }catch(ex){
        return defaultSettings;
    }
    
}