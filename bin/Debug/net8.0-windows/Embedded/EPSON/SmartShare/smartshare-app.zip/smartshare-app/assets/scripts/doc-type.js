var docTypes; 

/* = {
	"lstDocumentType": [
		{
			"dsTokenIntegracao": "",
			"customConfig": null,
			"help": "",
			"ordenacao": 1,
			"drawBorderDoc": 2,
			"required": false,
			"vlMinPaginas": 2,
			"idtd": "9",
			"nameTD": "Nota Fiscal",
			"canChangeAll": "0",
			"canChangeDuplex": "0",
			"tipo": "1",
			"densidade": "3",
			"tamanho": "1",
			"resolucao": "2",
			"lados": "1",
			"rotacao": "1",
			"zoom": "0",
            "isScanned": false,
            "vlPagesScanned": 0,
		}
	]
}
*/

MAX_DOC_LENGTH = 20;
var mainListDocs;
var showBtnSend = true;

function initDocType(){
    translateDocType(); 
    renderDocumentsTypes();
    
    renderHeader(translate.docTypeHeader, true, true);
    var indexResultInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
    if(Object.keys(indexResultInfo.scanSettings).length != 0){
        pollForUpdates();
    }
    

    renderPagination(appendDocTypeItems);
    
}

function renderDocumentsTypes() {
     var mainProcessInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
     docTypes = mainProcessInfo.docTypes;

    if (docTypes != null) {
        mainListDocs = docTypes.lstDocumentType;
        listitems = mainListDocs;
        updateListPage(appendDocTypeItems);
        showSendScan();
    } else {
        showNoItems(translate.documentoDocType);
    }
}

function showSendScan(){
    var footer = document.getElementById("div-footer");
    if(!footer){
        if(validateScanComplet()){
            renderFooter(false, "navigateTo('indexes.html')", true, "navigateTo('waitingSend.html')", true, appendDocTypeItems);
            var divSearchBox = document.getElementById('search-box-doc-type');
            divSearchBox.style.left = "100px";
        }
        else{
            renderFooter(true, "navigateTo('indexes.html')", false, "", true, appendDocTypeItems);
            var divSearchBox = document.getElementById('search-box-doc-type');
            divSearchBox.style.left = "195px";
        }
    }
}

function validateScanComplet() {    
    var scanned = false;
    for(i in mainListDocs) {
        var doc = mainListDocs[i];
        if(doc.required){
            if(!doc.scanned){
                return false;
            }else if(doc.vlMinPaginas>doc.vlPagesScanned){
                return false
            }
        }
        if(doc.scanned){
            scanned = true
        }
    }    
    return scanned;
}

function appendDocTypeItems(listDocs) {
    if (listDocs.length < 1) {
        showNoItems(translate.documentoDocType);
    } else {
        for(i in listDocs) {
            var doc = listDocs[i];

            var container = document.getElementById("container");
            container.appendChild(addDocTypeOnScreen(doc));
            if(doc.vlPagesScanned>0)
                docTypeModal(doc);
        }
    }
}

function addDocTypeOnScreen(doc) {
    var btnDoc = document.createElement("button");
    btnDoc.setAttribute("id", doc.idtd);
    btnDoc.setAttribute("onmouseup", "goToScanSettings(this)");
    btnDoc.classList.add("btn-doc-type");
    btnDoc.innerHTML = getTextButton(doc.nameTD, doc.required);

    btnDoc.appendChild(getStatusDocument(doc));

    if (doc.vlMinPaginas > 0) {
        btnDoc.appendChild(getVlPages(doc));
    }

    return btnDoc;
}

function getTextButton(docName, isRequired) {
    var btnText;
    if (docName.length > MAX_DOC_LENGTH)
        btnText = docName.substring(0, MAX_DOC_LENGTH) + "...";
    else
        btnText = docName;

    if (isRequired)
        btnText = btnText + "<span style='color: red;'>*</span>";

    return btnText;
}

function getStatusDocument(doc) {
    var statusDoc = document.createElement("img");
    statusDoc.classList.add("status-doc");

    switch(doc.drawBorderDoc) {
        case 2:
            //Documento expirado ou expirando
            statusDoc.setAttribute("src", "./assets/imgs/outdated.png");
            break;
        case 1:
            //Documento pulicado
            statusDoc.setAttribute("src", "./assets/imgs/published.png");
            break;
    }

    if (doc.scanned) {
        //Documento digitalizado
        statusDoc.setAttribute("src", "./assets/imgs/scanned.png");
    }

    return statusDoc;
}

function getVlPages(data) {
    var pagesRequired = document.createElement("span");
    pagesRequired.classList.add("doc-page-required");
    pagesRequired.innerText = "(" + data.vlPagesScanned + "/" + data.vlMinPaginas + ")";

    return pagesRequired;
}


function goToScanSettings(btnDoc) {
    for(i in mainListDocs) {
        var doc = mainListDocs[i];
        if (doc.idtd == parseInt(btnDoc.id)) {
            var docTypeNameSelected = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
            docTypeNameSelected.docTypeSelected = doc.nameTD;
            docTypeNameSelected.docTypeIdSelected = doc.idtd;
            window.sessionStorage.setItem("mainProcessInfo", JSON.stringify(docTypeNameSelected));
            //Definir o padrão de configurações de digitalização
            setDefaultScanSettings(doc);
            break;
        }
    }

    navigateTo("scan-properties.html");
}

function goToPreview(previewHtml){
    showSpinner();
    navigateTo(previewHtml);
}

function setDefaultScanSettings(doc) {
    var scanSettingsSelected = JSON.parse(window.sessionStorage.getItem("mainProcessInfo")); 
    mainScanSettings = {
        'vlPagesScanned': doc.vlPagesScanned,
        'canChangeAll': doc.canChangeAll,
        'canChangeDuplex': doc.canChangeDuplex,
        'defaultSettings': {
            'color_mode': getColorMode(doc.tipo),
            'resolution': getResolution(doc.resolucao),
            'density': getDensity(doc.densidade),
            'size': getSize(doc.tamanho),
            'orientation': getOrientation(doc.rotacao),
            'two_sided': getTwoSide(doc.lados)
        }
    }
    scanSettingsSelected.scanSettings = mainScanSettings;
    window.sessionStorage.setItem("mainProcessInfo", JSON.stringify(scanSettingsSelected));
}

function getColorMode(value) {
    return value == "2" ? "1" : "0";
}

function getOrientation(value) {
    return value == "2" ? "1" : "0";
}

function getTwoSide(value) {
    return value == "2" ? "1" : "0";
}

function getResolution(value) {
    switch(value){
        case "3":
        case "4":
            return "2";
        case "5":
            return "4";
        default:
            return "1";

    }
}

function getDensity(value) {
    switch(value) {
        case "3":
        case "4":
            return "0";
        case "5":
            return "2";
        default:
            return "-2";
    }
}

function getSize(value) {
    switch(value) {
        case "2":
            return "2";
        case "3":
            return "0";
        default:
            return "3";
    }
}

function pollForUpdates() {

    var successCallback = function(response) {

        var processInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo")); /*INSTANCIA*/
        processInfo.docTypes = JSON.parse(response);       
        window.sessionStorage.setItem("mainProcessInfo", JSON.stringify(processInfo)); /*SALVANDO O PREENCHIMENTO*/

        getVlPages(response);
        renderDocumentsTypes();
        
      };
    
      var failCallback = function(status) {
          if (status == 404)
              showConnectionLostError("tryAgain(listDocumentsType)");
          else
              showErrorModal();
      };
      reloadDocType("/process/document", "POST", "", successCallback, failCallback, "tryAgain(listDocumentsType)");
}

