
var mainScanSettings; 

/*= {
  'canChangeAll': false,
  'canChangeDuplex': false,
  'defaultSettins': {
    'color_mode': '0',
    'resolution': '1',
    'density': '-2',
    'size': '0',
    'orientation': '0',
    'two_sided': '0'
  }
}
*/

function navigateTo(path) {
    window.location.href = path;
}

function showSpinner() {
    var spinner = document.createElement("div");
    spinner.setAttribute("class", "spinner-bg");
    spinner.setAttribute("id", "spinner-bg");

    var gif = document.createElement("img");
    gif.setAttribute("src", "./assets/imgs/wait.gif");
    gif.setAttribute("class", "spinner-img");
    gif.setAttribute("id", "spinner-img");

    spinner.appendChild(gif);
    document.body.appendChild(spinner);
  }
  
  function hideSpinner() {
    setTimeout(function() {
      var spinner = document.getElementById("spinner-bg");
      if(spinner){
        document.body.removeChild(spinner);
      }
    }, 300);
  }

  function expandSearch() {
    var searchTxt = document.getElementById("search");
    searchTxt.classList.add("expanded");
  
    var searchImg = document.getElementById("search-img");
    searchImg.classList.add("activated");
  
    setTimeout(function(){ searchTxt.focus(); }, 10);    
  }

  function searchOnList(appendItems) {
    filter = document.getElementById("search").value
    listitemsFilter = [];
    state.page = 1;
    var screenName = getCurrentScreen();
    switch(screenName) {
      case "doc-type.html":
        for(i in listitems) {
          if (listitems[i].nameTD.toLowerCase().indexOf(filter.toLowerCase()) !== -1)
            listitemsFilter.push(listitems[i]);
        }
        break;
      case "index-result.html":
        for(i in listitems) {
          if (listitems[i].text.toLowerCase().indexOf(filter.toLowerCase()) !== -1)
            listitemsFilter.push(listitems[i]);
        }
        break;
      default:
        for(i in listitems) {
          if (listitems[i].processName.toLowerCase().indexOf(filter.toLowerCase()) !== -1)
            listitemsFilter.push(listitems[i]);
        }
        break;
    }
    
    updateListPage(appendItems);
  }

  function goToHomeDevice() {
    showQuestionModal("minimizeApp()");
  }

  function minimizeApp() {
    var successCallback = function(response) { closeModal(); }
    var failCallback = function(status) {
      closeModal();
      showErrorModal();
    }
    sendHttpRequest('/epson/changeToNativeScreen', 'GET', null, successCallback, failCallback, "tryAgain(minimizeApp)");
  }

  function tryAgain(callbackFunction) {
    closeModal();
    callbackFunction();
  }

  function showNoItems(screenName) {
    var content = document.getElementById("container");
    var message = document.createElement("span");
    message.id = "no-items"
    message.classList.add("no-items");
    message.innerHTML = translate.noItems1 + screenName.toLowerCase() + translate.noItems2;

    content.appendChild(message);
  }  

  function backToProcess(fromIndexesScreen) {
    var mainProcessInfo = JSON.parse(window.sessionStorage.getItem("mainProcessInfo"));
    process = mainProcessInfo.process;

    if(process.loginDisplay == "1" && fromIndexesScreen) {
      navigateTo("login.html");
    } else {
      window.sessionStorage.removeItem("mainProcessInfo");
      navigateTo("process.html");
    }
  }

  function getMainProcessInfoDefault() {
    return {
      "process": {},
      "indexes": {},
      "docTypes": {},
      "docTypeSelected":{},
      "docTypeIdSelected":{},
      "indexResult": {},
      "resultSelected": {},
      "scanSettings":{}
    };
  }

  function isLocalEnvironment() {
    var hostname = window.location.hostname;
    return hostname === 'localhost' || hostname.indexOf('127.') === 0 || hostname.indexOf('192.168.') === 0;
  }
  
  function getScreenNameIndex() {
    return isLocalEnvironment() ? 3 : 4;
  }

  function getCurrentScreen(){
    var url_atual = window.location.href;
    url_atual = url_atual.split('/');
    return url_atual[getScreenNameIndex()];
}  