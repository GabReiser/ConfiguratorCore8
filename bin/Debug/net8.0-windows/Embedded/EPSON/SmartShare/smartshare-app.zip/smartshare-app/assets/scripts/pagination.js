var listitems = [];
var listitemsFilter = [];
var filter;
var perPage = 3;
var state = { page: 1 }

function renderPagination(appendItems) {
  if (listitems.length > perPage) {
    btnNextPage(appendItems);
    btnPreviousPage(appendItems);    
  }
}

function nextPage(appendItems) {
    state.page++;
    if (state.page > Math.ceil(listitems.length/perPage)) {
      state.page = Math.ceil(listitems.length/perPage);
    }

    updateListPage(appendItems);
  }
  
  function previousPage(appendItems) {
    state.page--;
    if (state.page < 1) {
      state.page = 1;
    }

    updateListPage(appendItems);
  }

  function updateListPage(appendItems) {
    document.getElementById('container').innerHTML = '';
    
    var firstItem = (state.page - 1) * perPage;
    var lastItem = firstItem + perPage;
    var paginatedItemsList = [];

    if (filter == undefined)
      paginatedItemsList = listitems.slice(firstItem, lastItem);
    else
      paginatedItemsList = listitemsFilter.slice(firstItem, lastItem);

    try {//Na primeira vez que carrega, os botões de paginação ainda não existem
      if (filter == undefined)
        document.getElementById("btn-next").hidden = state.page == Math.ceil(listitems.length/perPage);
      else
        document.getElementById("btn-next").hidden = state.page == Math.ceil(listitemsFilter.length/perPage);
      
      document.getElementById("btn-prev").hidden = state.page == 1;
    } catch (error) {
      console.log("navegação ainda não existe.");
    }
    
    appendItems(paginatedItemsList);
  }