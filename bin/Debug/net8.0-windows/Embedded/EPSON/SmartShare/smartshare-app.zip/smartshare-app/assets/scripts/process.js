MAX_LENGTH = 30;
var processList;

function initProcess() {
    translateProcess();
    renderHeader(translate.selectProcessHeader, true, true);
    renderFooter(false, "", false, "", true, appendProcessItems);


    listProcess();
    renderPagination(appendProcessItems);
    translateProcess();
}

function appendProcessItems(listProcess) {
    if (listProcess.length < 1) {
        showNoItems(translate.process);
    } else {
        for (index in listProcess) {
            var process = listProcess[index];
            var content = document.getElementById("container");
            content.appendChild(addProcessItemOnScreen(process));
        }
    }    
}

function addProcessItemOnScreen(processitem) {
    var btnProcess = document.createElement("button");
    btnProcess.setAttribute("id", processitem.processId);
    if (processitem.processName.length > this.MAX_LENGTH)
        btnProcess.innerHTML = processitem.processName.substring(0, this.MAX_LENGTH) + "...";
    else
        btnProcess.innerHTML = processitem.processName;

    btnProcess.setAttribute("class", "btn-process");
    btnProcess.setAttribute("onmouseup", "selectProcess(this);");

    return btnProcess;
}

function selectProcess(btnProcess) {
    var process = getProcess(btnProcess.id);
    if(process.loginDisplay == 1){
        navigateTo("login.html");
    }else{
        listIndexes(JSON.stringify({ "processId" :  process.processId }));
    }
    
}

function getProcess(id) {
    for (i in processList){
        var process = processList[i];
        if(process.processId == id){
            var processInfo = getMainProcessInfoDefault();
            processInfo.process = process;
            window.sessionStorage.setItem("mainProcessInfo", JSON.stringify(processInfo));
            return process;
        }
    }
}